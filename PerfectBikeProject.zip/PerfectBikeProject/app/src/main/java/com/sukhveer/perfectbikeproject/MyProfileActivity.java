package com.sukhveer.perfectbikeproject;

import android.content.Context;
import android.database.Cursor;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyProfileActivity extends AppCompatActivity {

    EditText UserFirstNameET;
    EditText UserLastNameET;
    EditText UserIdET;
    Button SaveButton;
    Button ShowButton;
    Button UpdateButton;

    private DatabaseHelper databaseHelper;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);


        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

        }

        //   String GetPostalCode = getIntent().getStringExtra("EXTRA_SESSION_ID");

        databaseHelper = new DatabaseHelper(this);
        user = new User();
        UserIdET = (EditText)findViewById(R.id.EditTextUserID);
        UserFirstNameET = (EditText)findViewById(R.id.FirstNameID);
        UserLastNameET = (EditText)findViewById(R.id.LastNameID);

        SaveButton = (Button)findViewById(R.id.btnSave);
        ShowButton = (Button)findViewById(R.id.btnShow);
        UpdateButton =(Button)findViewById(R.id.btnUpdate);


        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                user.setUserId(Integer.valueOf(UserIdET.getText().toString().trim()));
                user.setFirstName(UserFirstNameET.getText().toString().trim());
                user.setLastName(UserLastNameET.getText().toString().trim());

                databaseHelper.addUser(user);
                Toast.makeText(getApplicationContext(), "Data Saved!", Toast.LENGTH_LONG).show();


            }
        });


        ShowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor res = databaseHelper.getAllData();
                if(res.getCount() == 0) {
                    // show message
                    showMessage("Error","Nothing found");
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("User ID :"+ res.getInt(0)+"\n");
                    buffer.append("First Name :"+ res.getString(1)+"\n");
                    buffer.append("Last Name :"+ res.getString(2)+"\n\n");

                }

                // Show all data
                showMessage("User Information",buffer.toString());

            }
        });



 /*       UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               boolean isUpdate = DatabaseHelper.updateData(UserIdET.getText().toString(),
                        UserFirstNameET.getText().toString(),
                        UserLastNameET.getText().toString());
                if(isUpdate == true)
                    Toast.makeText(MyProfileActivity.this,"Data Update",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MyProfileActivity.this,"Data not Updated",Toast.LENGTH_LONG).show();


            }
        });

*/


    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }
}
