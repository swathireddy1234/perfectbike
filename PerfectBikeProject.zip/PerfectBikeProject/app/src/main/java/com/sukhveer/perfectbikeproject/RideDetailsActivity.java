package com.sukhveer.perfectbikeproject;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.net.Uri;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class RideDetailsActivity extends AppCompatActivity implements LocationListener{

    TextView DisplayPostalCode;
    EditText DisplayDestValues;
    Button MapButton;
    EditText CurrentLocationV;
    EditText DistanceV;
    EditText CaloriesV;


    String Showmap = "http://maps.google.co.in/maps?q=";

    LocationManager locationManager;

    private String CLLongitude;
   private String CLLatitude;

    private String DLongitude;
    private String DLatitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_details);

if(getSupportActionBar()!=null){
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    getSupportActionBar().setDisplayShowHomeEnabled(true);

}

        // Current location Longitude and Latitude Access

        CurrentLocationV = (EditText) findViewById(R.id.CurrentLocValues);


        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        //current location acess function called which is implemented outside of OnCreate

        getLocation();

        // Destination Longitude and Latitude Access

        final String GetPostalCode = getIntent().getStringExtra("EXTRA_SESSION_ID");

        final Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> addresses = geocoder.getFromLocationName(GetPostalCode, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);

                // Use the address as needed

                DLatitude = String.valueOf(address.getLatitude());
                DLongitude = String.valueOf(address.getLongitude());

                // display message on text view
                DisplayDestValues = (EditText) findViewById(R.id.DestValues);
                DisplayDestValues.setText("Latitude: " + DLatitude + "\n Longitude: " + DLongitude);

            } else {

                // Display appropriate message when Geocoder services are not available
                Toast.makeText(this, "Sorry! You have Entered a Postal code that Does not Exist", Toast.LENGTH_LONG).show();
            }
        } catch (IOException e) {
            // handle exception
        }

        // display postal code only
        DisplayPostalCode = (TextView) findViewById(R.id.ShowPostalCode);
        DisplayPostalCode.setText(GetPostalCode);

    }


    //function that is called in OnCreate for current location longitude and latitude access

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, (LocationListener) this);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {

        CLLongitude = String.valueOf(location.getLongitude());
        CLLatitude = String.valueOf(location.getLatitude());

        CurrentLocationV.setText("Latitude: " + CLLatitude + "\n Longitude: " + CLLongitude);

        // Getting logitudes and latitudes again

        final String GetPostalCode = getIntent().getStringExtra("EXTRA_SESSION_ID");

        final Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> addresses = geocoder.getFromLocationName(GetPostalCode, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);

                DistanceV = (EditText)findViewById(R.id.DistanceET);
                CaloriesV = (EditText)findViewById(R.id.CaloriesET);



                final double desLatitude = address.getLatitude();
                final double desLongitude = address.getLongitude();

                final double CLatitude = location.getLatitude();
                final double CLongitude = location.getLongitude();


                // Distance calculations based on the above logitudes and latitudes

                double earthRadius = 6371;

                double dLat = Math.toRadians(desLatitude-CLatitude);
                double dLng = Math.toRadians(desLongitude-CLongitude);
                double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                        Math.cos(Math.toRadians(CLatitude)) * Math.cos(Math.toRadians(desLatitude)) *
                                Math.sin(dLng/2) * Math.sin(dLng/2);
                double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                double dist = earthRadius * c;

                String distance = String.valueOf(dist);
                DistanceV.setText(distance + " KM");


                // Calories Calculation by multiplying distace with 100

                double CaloriesDouble = dist * 100;
                String CaloriesString = String.valueOf(CaloriesDouble);
                CaloriesV.setText(CaloriesString + " Calories");



                // to open maps

                MapButton = (Button) findViewById(R.id.GoToMap);
                MapButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        // Changing doubles into string to pass to MapViewActivity

                        final String desLatitudeSend = String.valueOf(desLatitude);
                        final String desLongitudeSend = String.valueOf(desLongitude);
                        final String CLongitudeSend = String.valueOf(CLongitude);
                        final String CLatitudeSend = String.valueOf(CLatitude);



                        Intent MapViewIntent = new Intent(getApplicationContext(), MapViewActivity.class);

                        // passing longitudes and latitudes to MapViewActivity

                        MapViewIntent.putExtra("EXTRA_SESSION_ID1", desLatitudeSend);
                        MapViewIntent.putExtra("EXTRA_SESSION_ID2", desLongitudeSend);
                        MapViewIntent.putExtra("EXTRA_SESSION_ID3", CLatitudeSend);
                        MapViewIntent.putExtra("EXTRA_SESSION_ID4", CLongitudeSend);

                        startActivity(MapViewIntent);


                    }
                });


            } else {

                // Display appropriate message when Geocoder services are not available
                Toast.makeText(this, "Sorry! You have Entered a Postal code that Does not Exist", Toast.LENGTH_LONG).show();
            }
        } catch (IOException e) {
            // handle exception
        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(RideDetailsActivity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }
}
