package com.sukhveer.perfectbikeproject;
import android.app.ActionBar;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.support.design.widget.NavigationView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    final Context context = this;

    TextView textPostalCode;
    Button  btnSearch;
    EditText edtEnter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        textPostalCode = (TextView) findViewById(R.id.textPostalCode);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        edtEnter = (EditText) findViewById(R.id.EnterHere);


        edtEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String text = edtEnter.getEditableText().toString();
                int length = text.length();

                if (length == 6) {


                    boolean valid = true;
                    for (int i = 0; i < text.length(); i++) {
                        char a = text.charAt(0);
                        char b = text.charAt(2);
                        char c = text.charAt(4);
                        char d = text.charAt(1);
                        char e = text.charAt(3);
                        char f = text.charAt(5);
                        if (!Character.isLetter(a))
                            valid = false;
                        else if (!Character.isLetter(b))
                            valid = false;
                        else if (!Character.isLetter(c))
                            valid = false;
                        else if (!Character.isDigit(d))
                            valid = false;
                        else if (!Character.isDigit(e))
                            valid = false;
                        else if (!Character.isDigit(f))
                            valid = false;
                        break;
                    }

                    if (valid) {
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                context);

                        // set title
                        alertDialogBuilder.setTitle(text);

                        // set dialog message
                        alertDialogBuilder
                                .setMessage("Great! Your Postal Code Is Valid ! Press OK To Continue")


                                .setCancelable(false)


                                .setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        btnSearch.setVisibility(View.VISIBLE);
                                        btnSearch.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                Intent RideDetailsIntent = new Intent(getApplicationContext(), RideDetailsActivity.class);
                                                RideDetailsIntent.putExtra("EXTRA_SESSION_ID", text);
                                                startActivity(RideDetailsIntent);


                                            }
                                        });
                                        // dialog.cancel();


                                    }
                                });

                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();

                        // show it
                        alertDialog.show();

                    } else if (!valid) {


                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                context);

                        // set title
                        alertDialogBuilder.setTitle(text);

                        // set dialog message
                        alertDialogBuilder
                                .setMessage("InValid Format !")
                                .setCancelable(false)


                                .setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();

                        // show it
                        alertDialog.show();

                    }
                } else {

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            context);

                    // set title
                    alertDialogBuilder.setTitle(text);

                    // set dialog message
                    alertDialogBuilder
                            .setMessage("Postal Code Should Be Of 6 Characters !!")
                            .setCancelable(false)


                            .setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();
                }


            }
        });



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Hi This is Perfect Bike Application! ", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }


    @Override
    public boolean navigateUpTo(Intent upIntent) {
        return super.navigateUpTo(upIntent);
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        // Handle the Button action
        if (id == R.id.nav_MyProfile) {
            final String text = edtEnter.getEditableText().toString();
            Intent MyProfileIntent = new Intent(getApplicationContext(), MyProfileActivity.class);
            MyProfileIntent.putExtra("EXTRA_SESSION_ID", text);
            startActivity(MyProfileIntent);

        }

        else if (id == R.id.nav_MyBike) {

            final String text = edtEnter.getEditableText().toString();
            Intent MyBikeIntent = new Intent(getApplicationContext(), MyBikeActivity.class);
            MyBikeIntent.putExtra("EXTRA_SESSION_ID", text);
            startActivity(MyBikeIntent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
