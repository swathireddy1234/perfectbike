package com.sukhveer.perfectbikeproject;

import android.content.DialogInterface;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MapViewActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_view);



        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    private class FetchUrl extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... url) {
            String data = "";

            try {
                data = downloadUrl(url[0]);
                Log.d("Background Task data", data.toString());
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();
            parserTask.execute(result);

        }
    }
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            Log.d("downloadUrl", data.toString());
            br.close();
        } catch (Exception e) {
            Log.d("Exception", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Getting Longitude and Latitudes from RideDetailsActivity

        final String DesLatitudeRecieve = getIntent().getStringExtra("EXTRA_SESSION_ID1");
        final String DesLongitudeRecieve = getIntent().getStringExtra("EXTRA_SESSION_ID2");
        final String CLatitudeRecieve = getIntent().getStringExtra("EXTRA_SESSION_ID3");
        final String CLongitudeRecieve = getIntent().getStringExtra("EXTRA_SESSION_ID4");

        //Changinging latitude longitudes in to double
        Double a = Double.valueOf(DesLatitudeRecieve);
        Double b = Double.valueOf(DesLongitudeRecieve);
        Double c = Double.valueOf(CLatitudeRecieve);
        Double d = Double.valueOf(CLongitudeRecieve);

        LatLng Destination= new LatLng(a,b);
        LatLng CurrentLoc = new LatLng(c,d);



        mMap.addMarker(new MarkerOptions().position(CurrentLoc).title("CurrentLoc"));
        mMap.addMarker(new MarkerOptions().position(Destination).title("Destination"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Destination));

        String str_origin = "origin=" + Destination.latitude + "," + Destination.longitude;
        String str_dest = "destination=" + CurrentLoc.latitude + "," + CurrentLoc.longitude;
        String sensor = "sensor=false";
        String parameters = str_origin + "&" + str_dest + "&" + sensor;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

        Log.d("onMapClick", url.toString());
        FetchUrl FetchUrl = new FetchUrl();
        FetchUrl.execute(url);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Destination));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(7));

        Location Destination_location = new Location("Destination");
        Destination_location.setLatitude(Destination.latitude);
        Destination_location.setLongitude(Destination.longitude);

        Location CurrentLoc_location = new Location("CurrentLoc");
        CurrentLoc_location.setLatitude(CurrentLoc.latitude);
        CurrentLoc_location.setLongitude(CurrentLoc.longitude);

        double distance= (Destination_location.distanceTo(CurrentLoc_location)) * 0.000999999690624;
        // here we will get our result in metre so we multiply it by  0.000999999690624 to convert it to Kilometers

        AlertDialog alertDialog = new AlertDialog.Builder(MapViewActivity.this).create();
        alertDialog.setTitle("Welcome!");
        alertDialog.setMessage("Current Location and Destination Distance: "+distance +" KM");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();


        /*
        Toast.makeText(MapViewActivity.this, DesLatitudeRecieve, Toast.LENGTH_SHORT).show();
        Toast.makeText(MapViewActivity.this, DesLongitudeRecieve, Toast.LENGTH_SHORT).show();
        Toast.makeText(MapViewActivity.this, CLatitudeRecieve, Toast.LENGTH_SHORT).show();
        Toast.makeText(MapViewActivity.this, CLongitudeRecieve, Toast.LENGTH_SHORT).show();
        */

/*

        // Add a marker at destination and move the camera
        LatLng Destination = new LatLng(a, b);
        mMap.addMarker(new MarkerOptions().position(Destination).title("Destination"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Destination));

        LatLng CurrentLoc = new LatLng(c, d);
        mMap.addMarker(new MarkerOptions().position(CurrentLoc).title("Current Location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CurrentLoc));
*/

    }




    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                Log.d("ParserTask",jsonData[0].toString());
                JSONParserTask parser = new JSONParserTask();
                Log.d("ParserTask", parser.toString());
                routes = parser.parse(jObject);
                Log.d("ParserTask","Executing routes");
                Log.d("ParserTask",routes.toString());

            } catch (Exception e) {
                Log.d("ParserTask",e.toString());
                e.printStackTrace();
            }
            return routes;
        }
        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList<LatLng> points;
            PolylineOptions lineOptions = null;
            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList<>();
                lineOptions = new PolylineOptions();
                List<HashMap<String, String>> path = result.get(i);
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);
                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);
                    points.add(position);
                }
                lineOptions.addAll(points);
                lineOptions.width(10);
                lineOptions.color(Color.RED);

                Log.d("onPostExecute","onPostExecute lineoptions decoded");

            }
            if(lineOptions != null) {
                mMap.addPolyline(lineOptions);
            }
            else {
                Log.d("onPostExecute","without Polylines drawn");
            }
        }
    }


}
